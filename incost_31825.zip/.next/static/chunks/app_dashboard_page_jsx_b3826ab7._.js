(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/app/dashboard/page.jsx [app-client] (ecmascript)": ((__turbopack_context__) => {

var { k: __turbopack_refresh__, m: module, e: exports } = __turbopack_context__;
{
const e = new Error("Could not parse module '[project]/app/dashboard/page.jsx'\n\n'const' declarations must be initialized");
e.code = 'MODULE_UNPARSABLE';
throw e;
}}),
}]);