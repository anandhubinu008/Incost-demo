(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_d04e93f0._.js",
  "static/chunks/node_modules_8f276843._.js"
],
    source: "dynamic"
});
