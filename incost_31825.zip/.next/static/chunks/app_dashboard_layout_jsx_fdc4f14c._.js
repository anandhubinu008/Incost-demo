(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_ee6a9518._.js",
  "static/chunks/node_modules_5087dd00._.js"
],
    source: "dynamic"
});
