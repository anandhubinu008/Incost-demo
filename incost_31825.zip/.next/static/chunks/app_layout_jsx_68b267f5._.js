(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__288fc8c2._.css",
  "static/chunks/node_modules_next-themes_dist_index_mjs_2d467b86._.js"
],
    source: "dynamic"
});
